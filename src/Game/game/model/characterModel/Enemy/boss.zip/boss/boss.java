package Game.game.model.characterModel.Enemy.boss;

import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

public class boss {
    private head head;
    private hand hand1;
    private hand hand2;

    public boss() {
        head = new head();
        hand1 = new hand();
        hand2 = new hand();
    }

    public enum direction {
        right, left
    }

    public class hand {
        enum handForm {
            normal {
                @Override
                ArrayList<Point2D.Double> getVert(Point2D.Double center, direction direction) {
                    return null;
                }

                @Override
                BufferedImage getEmoji(direction direction) {
                    return null;
                }
            },
            punch {
                @Override
                ArrayList<Point2D.Double> getVert(Point2D.Double center, direction direction) {
                    switch (direction) {
                        case left -> {
                            ArrayList<Point2D.Double> result = new ArrayList<>();
                            result.add(new Point2D.Double(center.getX() + 10, center.getY()));
                            result.add(new Point2D.Double(center.getX() + 181, center.getY() + 6));
                            result.add(new Point2D.Double(center.getX() + 192, center.getY() + 88));
                            result.add(new Point2D.Double(center.getX() + 172, center.getY() + 100));
                            result.add(new Point2D.Double(center.getX() + 74, center.getY() + 100));
                            result.add(new Point2D.Double(center.getX() + 50, center.getY() + 60));
                            result.add(new Point2D.Double(center.getX(), center.getY() + 50));
                            return result;
                        }
                        case right -> {
                            ArrayList<Point2D.Double> result = new ArrayList<>();
                            result.add(new Point2D.Double(center.getX() + 10, center.getY() + 10));
                            result.add(new Point2D.Double(center.getX() + 181, center.getY()));
                            result.add(new Point2D.Double(center.getX() + 200, center.getY() + 45));
                            result.add(new Point2D.Double(center.getX() + 150, center.getY() + 60));
                            result.add(new Point2D.Double(center.getX() + 120, center.getY() + 100));
                            result.add(new Point2D.Double(center.getX() + 40, center.getY() + 120));
                            result.add(new Point2D.Double(center.getX() + 20, center.getY() + 103));
                            result.add(new Point2D.Double(center.getX(), center.getY() + 90));
                            return result;
                        }
                        case null, default -> {
                            return null;
                        }
                    }
                }

                @Override
                BufferedImage getEmoji(direction direction) {
                    return null;
                }
            }, gun, dike

            abstract ArrayList<Point2D.Double> getVert(Point2D.Double center,direction direction);

            abstract BufferedImage getEmoji(direction direction);
            }
    }

    public class head {
        enum headForm {
            smile {
                @Override
                BufferedImage getEmoji() {
                    return null;
                }
            }, angry {
                @Override
                BufferedImage getEmoji() {
                    return null;
                }
            }, dead {
                @Override
                BufferedImage getEmoji() {
                    return null;
                }
            }, shy {
                @Override
                BufferedImage getEmoji() {
                    return null;
                }
            };

            abstract ArrayList<Point2D.Double> getVert();

            abstract BufferedImage getEmoji();
        }
    }
}
